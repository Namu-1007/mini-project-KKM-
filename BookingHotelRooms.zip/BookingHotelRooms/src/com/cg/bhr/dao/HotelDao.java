package com.cg.bhr.dao;
import java.util.ArrayList;

import com.cg.bhr.bean.Hotel;
import com.cg.bhr.exception.BookingException;
public interface HotelDao
{
	public ArrayList<Hotel> searchAllHotels(String hotelName) throws BookingException;
	public ArrayList<Hotel> getAllHotels() throws BookingException;
	
}
