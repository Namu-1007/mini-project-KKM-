package com.cg.bhr.service;

import java.util.ArrayList;

import com.cg.bhr.bean.Hotel;
import com.cg.bhr.exception.BookingException;

public interface HotelService 
{
	public ArrayList<Hotel> searchAllHotels(String hotelName) throws BookingException;
	public ArrayList<Hotel> getAllHotels() throws BookingException;
}
