package com.cg.bhr.service;

import java.util.ArrayList;

import com.cg.bhr.bean.Hotel;
import com.cg.bhr.dao.HotelDao;
import com.cg.bhr.dao.HotelDaoImpl;
import com.cg.bhr.exception.BookingException;


public class HotelServiceImpl implements HotelService
{
	HotelDao hotelDao=null;
	public HotelServiceImpl()
	{
		hotelDao=new HotelDaoImpl();
	}
	@Override
	public ArrayList<Hotel> getAllHotels() throws BookingException 
	{
		
		return  hotelDao.getAllHotels(); 
	}
	@Override
	public ArrayList<Hotel> searchAllHotels(String hotelName)
			throws BookingException 
	{
		
		return hotelDao.searchAllHotels(hotelName);
	}
}
