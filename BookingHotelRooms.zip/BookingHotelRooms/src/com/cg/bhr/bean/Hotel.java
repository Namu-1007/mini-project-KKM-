package com.cg.bhr.bean;
public class Hotel 
{
	private String hotelId;
	private String city;
	private String hotelName;
	private String hotelAddr;
	private String hotelDesc;
	private float avgPerNight;
	private String phoneNo1;
	private String phoneNo2;
	private String rating;
	private String mail;
	private String fax;
	
	public String getHotelId() 
	{
		return hotelId;
	}
	public void setHotelId(String hotelId) 
	{
		this.hotelId = hotelId;
	}
	public String getCity() 
	{
		return city;
	}
	public void setCity(String city) 
	{
		this.city = city;
	}
	public String getHotelName() 
	{
		return hotelName;
	}
	public void setHotelName(String hotelName) 
	{
		this.hotelName = hotelName;
	}
	public String getHotelAddr()
	{
		return hotelAddr;
	}
	public void setHotelAddr(String hotelAddr) 
	{
		this.hotelAddr = hotelAddr;
	}
	public String getHotelDesc()
	{
		return hotelDesc;
	}
	public void setHotelDesc(String hotelDesc) 
	{
		this.hotelDesc = hotelDesc;
	}
	public float getAvgPerNight() 
	{
		return avgPerNight;
	}
	public void setAvgPerNight(float avgPerNight) 
	{
		this.avgPerNight = avgPerNight;
	}
	public String getPhoneNo1() 
	{
		return phoneNo1;
	}
	public void setPhoneNo1(String phoneNo1) 
	{
		this.phoneNo1 = phoneNo1;
	}
	public String getPhoneNo2()
	{
		return phoneNo2;
	}
	public void setPhoneNo2(String phoneNo2) 
	{
		this.phoneNo2 = phoneNo2;
	}
	public String getRating() 
	{
		return rating;
	}
	public void setRating(String rating)
	{
		this.rating = rating;
	}
	public String getMail()
	{
		return mail;
	}
	public void setMail(String mail) 
	{
		this.mail = mail;
	}
	public String getFax() 
	{
		return fax;
	}
	public void setFax(String fax) 
	{
		this.fax = fax;
	}
	
	public Hotel() 
	{
		super();
	}
	
	public Hotel(String hotelId, String city, String hotelName,
			String hotelAddr, String hotelDesc, float avgPerNight,
			String phoneNo1, String phoneNo2, String rating, String mail,
			String fax)
	{
		super();
		this.hotelId = hotelId;
		this.city = city;
		this.hotelName = hotelName;
		this.hotelAddr = hotelAddr;
		this.hotelDesc = hotelDesc;
		this.avgPerNight = avgPerNight;
		this.phoneNo1 = phoneNo1;
		this.phoneNo2 = phoneNo2;
		this.rating = rating;
		this.mail = mail;
		this.fax = fax;
	}
	
	@Override
	public String toString() 
	{
		return "Hotel [hotelId=" + hotelId + ", city=" + city + ", hotelName="
				+ hotelName + ", hotelAddr=" + hotelAddr + ", hotelDesc="
				+ hotelDesc + ", avgPerNight=" + avgPerNight + ", phoneNo1="
				+ phoneNo1 + ", phoneNo2=" + phoneNo2 + ", rating=" + rating
				+ ", mail=" + mail + ", fax=" + fax + "]";
	}
}
